
<?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php $component = App\View\Components\Header::resolve(['title' => 'Login | Fashion E-commerce','description' => 'login Page of fashion ecommerce','keywords' => 'login ecommerce multirole client'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>

    <!-- login Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="section-title">
                <h2>Sign in For Your Dashboard</h2>
                <span>Sign in now!!!</span>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 mx-auto">
                    <div class="msg">
                        <?php if(Session::has("success")): ?>
                        <p class='alert alert-success'><?php echo e(Session::get('success')); ?></p>
                        <?php endif; ?>
                        <?php if(Session::has("error")): ?>
                        <p class='alert alert-danger'><?php echo e(Session::get('error')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="contact__form">
                        <form action="<?php echo e(URL::to('/signinUser')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <input type="text" name='email' placeholder="E-mail" require>
                                </div>
                                <div class="col-lg-12">
                                    <input type="password" name='password' placeholder='Password' require>
                                    <button type="submit" name='signin' class="site-btn">Sign In</button>
                                    <a href="<?php echo e(URL::to('google/login')); ?>">
                                        <img src="<?php echo e(URL::asset('googlesignin.png')); ?>" style='height: 120px;' alt="">
                                    </a>
                                </div>

                            </div>
                            <p>Don't have any account? Click here for <a href="<?php echo e(URL::to('/register')); ?>">Register</a></p>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- login Section End -->

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\ecompro\resources\views/login.blade.php ENDPATH**/ ?>