
<?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php $component = App\View\Components\Header::resolve(['title' => 'My Orders | Fashion E-commerce','description' => 'my orders Page of fashion ecommerce','keywords' => 'my orders ecommerce multirole client'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="section-title">
                <h2>My account</h2>
                <span>My Orders History</span>
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-8 mx-auto">
                    <table class='table table-striped'>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Total Bill</th>
                                <th>Name</th>
                                <th>Cell Number</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Order Date</th>
                                <th>View Product</th>
                            </tr>
                        </thead>
                        <?php
                         $i=0;   
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                            ?>
                            <tr>
                                <th>
                                    <?php echo e($i); ?>

                                </th>
                                <th>$<?php echo e($items->bill); ?></th>
                                <th><?php echo e($items->fullname); ?></th>
                                <th><?php echo e($items->cell); ?></th>
                                <th><?php echo e($items->address); ?></th>
                                <th><?php echo e($items->status); ?></th>
                                <th><?php echo e($items->created_at); ?></th>
                                <th>

                            <!-- Button to Open the Modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal<?php echo e($i); ?>">
                            Products
                        </button>
  
                                <!-- The Modal -->
                                <div class="modal" id="myModal<?php echo e($i); ?>">
                                    <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                        <!-- Modal Header -->
                                        <div class="modal-header">
                                        <h4 class="modal-title">Modal Heading</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                
                                        <!-- Modal body -->
                                        <div class="modal-body">
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Product Image</th>
                                                        <th>Product Title</th>
                                                        <th>Price</th>
                                                        <th>Quantites</th>
                                                        <th>Sub Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $all_order_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($items->id == $product->orderId): ?>
                                                    <tr>
                                                        <td><img style='width: 100px;' src="<?php echo e(URL::asset("uploads/products/". $product->image)); ?>" alt=""></td>
                                                        <td><?php echo e($product->title); ?>, <?php echo e($product->orderId); ?></td>
                                                        <td><?php echo e($product->price); ?></td>
                                                        <td><?php echo e($product->quantites); ?></td>
                                                        <td><?php echo e($product->price * $product->quantites); ?></td>
                                                    </tr>
                                                   <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                
                                        <!-- Modal footer -->
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                
                                    </div>
                                    </div>
                                </div>

                                </th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> 
            </div>
        </div>
    </section>
    <!-- Contact Section End -->

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\ecompro\resources\views/orders.blade.php ENDPATH**/ ?>