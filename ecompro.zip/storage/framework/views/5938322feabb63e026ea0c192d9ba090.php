<!DOCTYPE html>
<html>
<head>
    <title>Laravel - Stripe Payment Gateway Integration Example - ItSolutionStuff.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
    
<div class="container">
    
    <h1 class='text-center p-3'>Send Payment Using Stripe payment Gateway.</h1>
    <?php echo e($fullname); ?>

    <?php echo e($address); ?>

    <?php echo e($cell); ?>

    <?php echo e($bill); ?>

    
   
</div>
    
</body>
    
</html><?php /**PATH F:\xampp\htdocs\ecompro\resources\views/stripe.blade.php ENDPATH**/ ?>