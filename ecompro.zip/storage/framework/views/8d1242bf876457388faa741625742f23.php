<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>payment</title>
</head>
<body>
    <h1>payment page</h1>
    <?php echo e($fullname); ?>

    <?php echo e($bill); ?>

    <?php echo e($cell); ?>

    <?php echo e($address); ?>

</body>
</html><?php /**PATH F:\xampp\htdocs\ecompro\resources\views/paybill.blade.php ENDPATH**/ ?>