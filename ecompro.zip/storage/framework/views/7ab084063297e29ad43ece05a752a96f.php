
<?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>


    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__text">
                        <h4>Shopping Cart</h4>
                        <div class="breadcrumb__links">
                            <a href="./index.html">Home</a>
                            <a href="./shop.html">Shop</a>
                            <span>Shopping Cart</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Shopping Cart Section Begin -->
    <section class="shopping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="shopping__cart__table">
                        <?php if(Session::has('success')): ?>
                        <p class='alert alert-success'><?php echo e(Session::get("success")); ?> <button class='close' data-dismissed='alert'>&times;</button> </p>

                        <?php endif; ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $total=0;    

                                ?>
                                <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="product__cart__item">
                                        <div class="product__cart__item__pic">
                                            <img src="<?php echo e(URL::asset('uploads/products/'.$items->image)); ?>" alt="">
                                        </div>
                                        <div class="product__cart__item__text">
                                            <h6><?php echo e($items->title); ?></h6>
                                            <h5><?php echo e($items->price); ?></h5>
                                        </div>
                                    </td>
                                    <td class="quantity__item">
                                        <form action="<?php echo e(route('update.cart', $items->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="quantity">
                                                <input type="number" name='quantity' min='1' max="<?php echo e($items->pQuantity); ?>" value="<?php echo e($items->quantites); ?>">
                                            </div>
                                            <input type="hidden" name='id' value="<?php echo e($items->id); ?>">
                                            <input type="submit" class='btn btn-success' value="Update">
                                        </form>
                                    </td>
                                    <td class="cart__price">$<?php echo e($items->price * $items->quantites); ?></td>
                                    <td class="cart__close"><a href="<?php echo e(route('delete.cart', $items->id)); ?>"><i class="fa fa-close"></i></a></td>
                                </tr>
                                <?php
                                    $total+= ($items->price * $items->quantites);
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="continue__btn">
                                <a href="#">Continue Shopping</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="continue__btn update__btn">
                                <a href="#"><i class="fa fa-spinner"></i> Update cart</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="cart__discount">
                        <h6>Discount codes</h6>
                        <form action="#">
                            <input type="text" placeholder="Coupon code">
                            <button type="submit">Apply</button>
                        </form>
                    </div>
                    <div class="cart__total">
                        <h6>Cart total</h6>
                        <ul>
                            <li>Subtotal <span>$ <?php echo e($total); ?></span></li>
                            <li>Total <span>$ <?php echo e($total); ?></span></li>
                        </ul>
                        <form action="<?php echo e(route('page.stripe')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <input type="text" name='fullname' placeholder="Enter your full name.." class='form-control mt-2' required>
                            <input type="text" name='cell' placeholder="Enter your cell number.." class='form-control mt-2' required>
                            <input type="text" name='address' placeholder="Enter your full address.." class='form-control mt-2' required>
                            <input type="hidden" name='bill' value='<?php echo e($total); ?>'>
                            <input type="submit" value="Proceed to checkout" class="primary-btn mt-2 btn btn-block">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shopping Cart Section End -->

    

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\ecompro\resources\views/shopping-cart.blade.php ENDPATH**/ ?>