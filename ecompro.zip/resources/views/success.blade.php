<x-header title="Shopping Cart | Fashion E-commerce" description="Shopping cart Page of fashion ecommercer" keywords='home ecommerce multirole client' />

<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perspiciatis doloremque, voluptatem, ipsa accusantium impedit inventore deserunt consectetur</p>
    <h1 class='bg-success text-white p-2 my-2 mx-auto text-center fw-bold fst-italic rounded' >{{$msg}}</h1>
    <p>Thanks for purchasing products from us. Your product will deliver soon.</p>



    <a class='btn btn-success btn-lg' href="{{route('main.index')}}">Go to home.</a>


<x-footer />